// КВИЗ ПОДБОРА ТЕХНИКИ
const quizQuestions = [
  {
    id: 1,
    question: "Какой тип устройства вас интересует?",
    icon: "📱",
    options: [
      { id: "smartphone", text: "Смартфон", icon: "📱", description: "Мобильное устройство для связи и развлечений" },
      { id: "laptop", text: "Ноутбук", icon: "💻", description: "Портативный компьютер для работы и учебы" },
      { id: "headphones", text: "Наушники", icon: "🎧", description: "Аудиоустройство для музыки и звонков" },
      { id: "gaming", text: "Игровое устройство", icon: "🎮", description: "Консоль или аксессуары для игр" }
    ]
  },
  {
    id: 2,
    question: "Какой у вас бюджет?",
    icon: "💰",
    options: [
      { id: "budget", text: "До 30,000 ₽", icon: "💵", description: "Экономичные решения" },
      { id: "medium", text: "30,000 - 80,000 ₽", icon: "💴", description: "Средний ценовой сегмент" },
      { id: "premium", text: "80,000 - 150,000 ₽", icon: "💶", description: "Премиум устройства" },
      { id: "luxury", text: "Свыше 150,000 ₽", icon: "💎", description: "Топовые флагманы" }
    ]
  },
  {
    id: 3,
    question: "Для каких целей планируете использовать?",
    icon: "🎯",
    options: [
      { id: "basic", text: "Базовые задачи", icon: "📝", description: "Звонки, сообщения, интернет" },
      { id: "work", text: "Работа и учеба", icon: "💼", description: "Офисные приложения, презентации" },
      { id: "creative", text: "Творчество", icon: "🎨", description: "Фото, видео, дизайн" },
      { id: "gaming", text: "Игры", icon: "🎮", description: "Современные игры и развлечения" }
    ]
  },
  {
    id: 4,
    question: "Насколько важна портативность?",
    icon: "🎒",
    options: [
      { id: "very", text: "Очень важна", icon: "🏃", description: "Постоянно в движении" },
      { id: "important", text: "Важна", icon: "🚶", description: "Иногда беру с собой" },
      { id: "neutral", text: "Не очень важна", icon: "🏠", description: "В основном дома/офисе" },
      { id: "not", text: "Не важна", icon: "🪑", description: "Стационарное использование" }
    ]
  },
  {
    id: 5,
    question: "Какие бренды предпочитаете?",
    icon: "🏷️",
    options: [
      { id: "apple", text: "Apple", icon: "🍎", description: "Экосистема Apple" },
      { id: "samsung", text: "Samsung", icon: "📱", description: "Инновации Samsung" },
      { id: "xiaomi", text: "Xiaomi", icon: "⚡", description: "Соотношение цена/качество" },
      { id: "any", text: "Любой", icon: "🌟", description: "Главное - характеристики" }
    ]
  },
  {
    id: 6,
    question: "Как часто обновляете технику?",
    icon: "🔄",
    options: [
      { id: "yearly", text: "Каждый год", icon: "📅", description: "Всегда новинки" },
      { id: "2years", text: "Раз в 2-3 года", icon: "⏰", description: "Регулярные обновления" },
      { id: "5years", text: "Раз в 4-5 лет", icon: "⌛", description: "Долгосрочное использование" },
      { id: "rarely", text: "Очень редко", icon: "🐌", description: "До полного износа" }
    ]
  },
  {
    id: 7,
    question: "Что важнее всего в устройстве?",
    icon: "⭐",
    options: [
      { id: "performance", text: "Производительность", icon: "🚀", description: "Скорость и мощность" },
      { id: "battery", text: "Время работы", icon: "🔋", description: "Долгая автономность" },
      { id: "camera", text: "Камера", icon: "📸", description: "Качество фото и видео" },
      { id: "design", text: "Дизайн", icon: "✨", description: "Внешний вид и эргономика" }
    ]
  },
  {
    id: 8,
    question: "Готовы ли покупать новинки?",
    icon: "🆕",
    options: [
      { id: "yes", text: "Да, обязательно", icon: "🔥", description: "Только последние модели" },
      { id: "maybe", text: "Возможно", icon: "🤔", description: "Если есть преимущества" },
      { id: "prefer_tested", text: "Предпочитаю проверенные", icon: "✅", description: "Модели с отзывами" },
      { id: "no", text: "Нет", icon: "❌", description: "Только надежные решения" }
    ]
  }
];

// Рекомендации на основе ответов
const recommendations = {
  smartphone: {
    budget: [
      { id: 1, name: "Samsung Galaxy A06", price: 15990, image: "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=300", match: 95 },
      { id: 5, name: "Xiaomi Redmi Note 13", price: 24990, image: "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=300", match: 90 }
    ],
    medium: [
      { id: 5, name: "Xiaomi Redmi Note 13", price: 24990, image: "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=300", match: 95 }
    ],
    premium: [
      { id: 4, name: "iPhone 15", price: 89990, image: "https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=300", match: 98 }
    ]
  },
  laptop: {
    budget: [
      { id: 7, name: "Lenovo ThinkPad E15", price: 45990, image: "https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=300", match: 92 }
    ],
    medium: [
      { id: 2, name: "ASUS ROG Strix G15", price: 159990, image: "https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=300", match: 94 }
    ],
    premium: [
      { id: 6, name: "MacBook Pro 16\"", price: 249990, image: "https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=300", match: 97 }
    ]
  },
  headphones: {
    budget: [
      { id: 9, name: "JBL Tune 510BT", price: 3990, image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=300", match: 88 }
    ],
    medium: [
      { id: 3, name: "Sony WH-1000XM5", price: 29990, image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=300", match: 96 },
      { id: 8, name: "AirPods Pro 2", price: 24990, image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=300", match: 93 }
    ]
  },
  gaming: {
    medium: [
      { id: 12, name: "Nintendo Switch OLED", price: 34990, image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=300", match: 91 }
    ],
    premium: [
      { id: 10, name: "PlayStation 5", price: 54990, image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=300", match: 96 },
      { id: 11, name: "Xbox Series X", price: 49990, image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=300", match: 94 }
    ]
  }
};

// Состояние квиза
let currentQuestionIndex = 0;
let answers = {};
let isQuizCompleted = false;

// Инициализация квиза
document.addEventListener('DOMContentLoaded', function() {
  initQuiz();
  updateCartCount();
});

function initQuiz() {
  showQuestion(0);
  updateProgress();
}

// Показать вопрос
function showQuestion(index) {
  const question = quizQuestions[index];
  const container = document.getElementById('quiz-container');
  
  container.innerHTML = `
    <div class="question-card">
      <div class="question-icon">${question.icon}</div>
      <h2 class="question-title">${question.question}</h2>
      <div class="options-grid">
        ${question.options.map(option => `
          <div class="option-card" onclick="selectOption(${question.id}, '${option.id}', this)">
            <div class="option-icon">${option.icon}</div>
            <h3 class="option-title">${option.text}</h3>
            <p class="option-description">${option.description}</p>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  
  // Восстановить выбранный ответ если есть
  if (answers[question.id]) {
    const selectedOption = container.querySelector(`[onclick*="'${answers[question.id]}'"]`);
    if (selectedOption) {
      selectedOption.classList.add('selected');
    }
  }
}

// Выбор опции
function selectOption(questionId, optionId, element) {
  // Убрать выделение с других опций
  const allOptions = element.parentNode.querySelectorAll('.option-card');
  allOptions.forEach(option => option.classList.remove('selected'));
  
  // Выделить выбранную опцию
  element.classList.add('selected');
  
  // Сохранить ответ
  answers[questionId] = optionId;
  
  // Активировать кнопку "Далее"
  document.getElementById('next-btn').disabled = false;
}

// Следующий вопрос
function nextQuestion() {
  if (currentQuestionIndex < quizQuestions.length - 1) {
    currentQuestionIndex++;
    showQuestion(currentQuestionIndex);
    updateProgress();
    updateNavigation();
  } else {
    completeQuiz();
  }
}

// Предыдущий вопрос
function previousQuestion() {
  if (currentQuestionIndex > 0) {
    currentQuestionIndex--;
    showQuestion(currentQuestionIndex);
    updateProgress();
    updateNavigation();
  }
}

// Обновить прогресс
function updateProgress() {
  const progress = ((currentQuestionIndex + 1) / quizQuestions.length) * 100;
  document.getElementById('progress-fill').style.width = progress + '%';
  document.getElementById('current-question').textContent = currentQuestionIndex + 1;
}

// Обновить навигацию
function updateNavigation() {
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  
  prevBtn.disabled = currentQuestionIndex === 0;
  nextBtn.disabled = !answers[quizQuestions[currentQuestionIndex].id];
  
  if (currentQuestionIndex === quizQuestions.length - 1) {
    nextBtn.textContent = 'ПОЛУЧИТЬ РЕКОМЕНДАЦИИ';
  } else {
    nextBtn.textContent = 'ДАЛЕЕ';
  }
}

// Завершить квиз
function completeQuiz() {
  isQuizCompleted = true;
  
  // Показать загрузку
  const container = document.getElementById('quiz-container');
  container.innerHTML = `
    <div class="loading-screen">
      <div class="loading-animation">
        <div class="loading-spinner"></div>
        <h2>АНАЛИЗИРУЕМ ВАШИ ОТВЕТЫ...</h2>
        <p>Подбираем идеальную технику специально для вас</p>
        <div class="loading-steps">
          <div class="loading-step active">🔍 Анализ потребностей</div>
          <div class="loading-step">🤖 ИИ-подбор</div>
          <div class="loading-step">✅ Верификация</div>
        </div>
      </div>
    </div>
  `;
  
  // Скрыть навигацию
  document.querySelector('.quiz-navigation').style.display = 'none';
  
  // Анимация загрузки
  setTimeout(() => {
    document.querySelectorAll('.loading-step')[1].classList.add('active');
  }, 1000);
  
  setTimeout(() => {
    document.querySelectorAll('.loading-step')[2].classList.add('active');
  }, 2000);
  
  // Показать результаты
  setTimeout(() => {
    showResults();
  }, 3000);
}

// Показать результаты
function showResults() {
  document.getElementById('quiz-container').style.display = 'none';
  document.getElementById('quiz-results').style.display = 'block';
  
  const deviceType = answers[1]; // Тип устройства
  const budget = answers[2]; // Бюджет
  
  const deviceRecommendations = recommendations[deviceType];
  let finalRecommendations = [];
  
  if (deviceRecommendations && deviceRecommendations[budget]) {
    finalRecommendations = deviceRecommendations[budget];
  } else if (deviceRecommendations) {
    // Если нет точного совпадения, берем любые рекомендации для этого типа
    finalRecommendations = Object.values(deviceRecommendations).flat();
  }
  
  // Если рекомендаций мало, добавляем из других категорий
  if (finalRecommendations.length < 3) {
    const allRecommendations = Object.values(recommendations).flat().map(cat => Object.values(cat)).flat().flat();
    const additionalRecs = allRecommendations.filter(rec => 
      !finalRecommendations.find(existing => existing.id === rec.id)
    ).slice(0, 3 - finalRecommendations.length);
    finalRecommendations = [...finalRecommendations, ...additionalRecs];
  }
  
  // Ограничиваем до 3 рекомендаций
  finalRecommendations = finalRecommendations.slice(0, 3);
  
  const grid = document.getElementById('recommendations-grid');
  grid.innerHTML = finalRecommendations.map(product => `
    <div class="recommendation-card" data-3d="true">
      <div class="recommendation-match">${product.match}% совпадение</div>
      <div class="recommendation-image">
        <img src="${product.image}" alt="${product.name}">
      </div>
      <div class="recommendation-info">
        <h3>${product.name}</h3>
        <div class="recommendation-price">${product.price.toLocaleString()} ₽</div>
        <button class="recommendation-btn" onclick="addToCart(${product.id})">ДОБАВИТЬ В КОРЗИНУ</button>
      </div>
    </div>
  `).join('');
  
  // Сохранить результаты в localStorage
  localStorage.setItem('deviceUP_quiz_results', JSON.stringify({
    answers: answers,
    recommendations: finalRecommendations,
    timestamp: Date.now()
  }));
}

// Перезапустить квиз
function restartQuiz() {
  currentQuestionIndex = 0;
  answers = {};
  isQuizCompleted = false;
  
  document.getElementById('quiz-container').style.display = 'block';
  document.getElementById('quiz-results').style.display = 'none';
  document.querySelector('.quiz-navigation').style.display = 'flex';
  
  initQuiz();
}

// Обновление счетчика корзины
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('deviceUP_cart')) || [];
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  const cartCountElement = document.getElementById('cart-count');
  if (cartCountElement) {
    cartCountElement.textContent = count;
  }
}

// Добавление в корзину из рекомендаций
function addToCart(productId) {
  let cart = JSON.parse(localStorage.getItem('deviceUP_cart')) || [];
  const existingItem = cart.find(item => item.id === productId);
  
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ id: productId, quantity: 1 });
  }
  
  localStorage.setItem('deviceUP_cart', JSON.stringify(cart));
  updateCartCount();
  
  // Визуальная обратная связь
  const button = event.target;
  const originalText = button.textContent;
  button.textContent =  '✓ ДОБАВЛЕНО';
  button.style.background = '#4CAF50';
  
  setTimeout(() => {
    button.textContent = originalText;
    button.style.background = '';
  }, 2000);
  
  showNotification('Товар добавлен в корзину!');
}

// Стили для квиза
const quizStyles = `
  .quiz-page {
    padding-top: 100px;
    min-height: 100vh;
  }
  
  .quiz-header {
    text-align: center;
    margin-bottom: 50px;
  }
  
  .quiz-title {
    font-family: 'Orbitron', monospace;
    font-size: clamp(2rem, 5vw, 3.5rem);
    color: #ffffff;
    margin-bottom: 15px;
    text-shadow: 0 0 20px #00f5ff;
  }
  
  .quiz-subtitle {
    font-size: 1.2rem;
    color: #cccccc;
    margin-bottom: 40px;
  }
  
  .progress-container {
    max-width: 600px;
    margin: 0 auto;
  }
  
  .progress-bar {
    width: 100%;
    height: 8px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 15px;
  }
  
  .progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #00f5ff, #bd00ff);
    border-radius: 10px;
    transition: width 0.5s ease;
    width: 12.5%;
  }
  
  .progress-text {
    color: #00f5ff;
    font-weight: 600;
    font-size: 1.1rem;
  }
  
  .quiz-container {
    max-width: 800px;
    margin: 0 auto 50px;
  }
  
  .question-card {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(0, 245, 255, 0.3);
    border-radius: 25px;
    padding: 40px;
    text-align: center;
    backdrop-filter: blur(10px);
  }
  
  .question-icon {
    font-size: 4rem;
    margin-bottom: 25px;
  }
  
  .question-title {
    font-size: 1.8rem;
    color: #ffffff;
    margin-bottom: 40px;
    font-weight: 600;
  }
  
  .options-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
  }
  
  .option-card {
    background: rgba(255, 255, 255, 0.05);
    border: 2px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-align: center;
  }
  
  .option-card:hover {
    border-color: rgba(0, 245, 255, 0.5);
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 245, 255, 0.2);
  }
  
  .option-card.selected {
    border-color: #00f5ff;
    background: rgba(0, 245, 255, 0.1);
    box-shadow: 0 0 20px rgba(0, 245, 255, 0.3);
  }
  
  .option-icon {
    font-size: 2.5rem;
    margin-bottom: 15px;
  }
  
  .option-title {
    color: #ffffff;
    font-size: 1.2rem;
    margin-bottom: 10px;
    font-weight: 600;
  }
  
  .option-description {
    color: #cccccc;
    font-size: 0.9rem;
    line-height: 1.4;
  }
  
  .quiz-navigation {
    display: flex;
    justify-content: center;
    gap: 30px;
    margin-bottom: 50px;
  }
  
  .nav-btn {
    padding: 15px 40px;
    border-radius: 30px;
    font-weight: bold;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  
  .nav-btn.primary {
    background: linear-gradient(45deg, #00f5ff, #bd00ff);
    border: none;
    color: white;
  }
  
  .nav-btn.secondary {
    background: transparent;
    border: 2px solid #00f5ff;
    color: #00f5ff;
  }
  
  .nav-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  
  .nav-btn:not(:disabled):hover {
    transform: scale(1.05);
    box-shadow: 0 10px 30px rgba(0, 245, 255, 0.3);
  }
  
  .loading-screen {
    text-align: center;
    padding: 60px 20px;
  }
  
  .loading-spinner {
    width: 80px;
    height: 80px;
    border: 4px solid rgba(0, 245, 255, 0.3);
    border-top: 4px solid #00f5ff;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 30px;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  
  .loading-animation h2 {
    color: #ffffff;
    font-size: 2rem;
    margin-bottom: 15px;
    font-family: 'Orbitron', monospace;
  }
  
  .loading-animation p {
    color: #cccccc;
    font-size: 1.1rem;
    margin-bottom: 40px;
  }
  
  .loading-steps {
    display: flex;
    justify-content: center;
    gap: 30px;
    flex-wrap: wrap;
  }
  
  .loading-step {
    padding: 10px 20px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 25px;
    color: #888888;
    transition: all 0.5s ease;
  }
  
  .loading-step.active {
    border-color: #00f5ff;
    color: #00f5ff;
    box-shadow: 0 0 15px rgba(0, 245, 255, 0.3);
  }
  
  .quiz-results {
    text-align: center;
  }
  
  .results-title {
    font-family: 'Orbitron', monospace;
    font-size: 2.5rem;
    color: #ffffff;
    margin-bottom: 15px;
    text-shadow: 0 0 20px #00f5ff;
  }
  
  .results-subtitle {
    font-size: 1.2rem;
    color: #cccccc;
    margin-bottom: 50px;
  }
  
  .recommendations-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    margin-bottom: 50px;
  }
  
  .recommendation-card {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(0, 245, 255, 0.3);
    border-radius: 20px;
    padding: 25px;
    position: relative;
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
  }
  
  .recommendation-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 245, 255, 0.2);
  }
  
  .recommendation-match {
    position: absolute;
    top: 15px;
    right: 15px;
    background: linear-gradient(45deg, #00f5ff, #bd00ff);
    color: white;
    padding: 5px 15px;
    border-radius: 15px;
    font-size: 0.9rem;
    font-weight: bold;
  }
  
  .recommendation-image {
    margin-bottom: 20px;
  }
  
  .recommendation-image img {
    width: 100%;
    max-width: 200px;
    height: 200px;
    object-fit: cover;
    border-radius: 15px;
  }
  
  .recommendation-info h3 {
    color: #ffffff;
    font-size: 1.3rem;
    margin-bottom: 15px;
  }
  
  .recommendation-price {
    color: #00f5ff;
    font-size: 1.5rem;
    font-weight: bold;
    margin-bottom: 20px;
  }
  
  .recommendation-btn {
    width: 100%;
    background: linear-gradient(45deg, #00f5ff, #bd00ff);
    border: none;
    color: white;
    padding: 12px;
    border-radius: 10px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
  }
  
  .recommendation-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(0, 245, 255, 0.3);
  }
  
  .results-actions {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
  }
  
  @media (max-width: 768px) {
    .quiz-title {
      font-size: 2rem;
    }
    
    .options-grid {
      grid-template-columns: 1fr;
    }
    
    .quiz-navigation {
      flex-direction: column;
      align-items: center;
    }
    
    .nav-btn {
      width: 200px;
    }
    
    .loading-steps {
      flex-direction: column;
      align-items: center;
    }
    
    .recommendations-grid {
      grid-template-columns: 1fr;
    }
    
    .results-actions {
      flex-direction: column;
      align-items: center;
    }
  }
`;

// Добавляем стили в документ
const styleSheet = document.createElement('style');
styleSheet.textContent = quizStyles;
document.head.appendChild(styleSheet);