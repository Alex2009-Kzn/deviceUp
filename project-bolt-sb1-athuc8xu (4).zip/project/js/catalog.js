// КАТАЛОГ ТОВАРОВ
const catalogProducts = [
  // Смартфоны
  {
    id: 1,
    name: 'Samsung Galaxy A06',
    category: 'smartphones',
    level: 'level1',
    price: 15990,
    oldPrice: 18990,
    rating: 4.2,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Базовый смартфон для повседневных задач'
  },
  {
    id: 4,
    name: 'iPhone 15',
    category: 'smartphones',
    level: 'level3',
    price: 89990,
    oldPrice: 99990,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Флагманский смартфон с передовыми технологиями'
  },
  {
    id: 5,
    name: 'Xiaomi Redmi Note 13',
    category: 'smartphones',
    level: 'level2',
    price: 24990,
    oldPrice: 29990,
    rating: 4.5,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Сбалансированный смартфон среднего класса'
  },
  
  // Ноутбуки
  {
    id: 2,
    name: 'ASUS ROG Strix G15',
    category: 'laptops',
    level: 'gaming',
    price: 159990,
    oldPrice: 179990,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Игровой ноутбук для киберспорта'
  },
  {
    id: 6,
    name: 'MacBook Pro 16"',
    category: 'laptops',
    level: 'creator',
    price: 249990,
    oldPrice: 279990,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Профессиональный ноутбук для творчества'
  },
  {
    id: 7,
    name: 'Lenovo ThinkPad E15',
    category: 'laptops',
    level: 'level1',
    price: 45990,
    oldPrice: 52990,
    rating: 4.3,
    image: 'https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Надежный ноутбук для работы и учебы'
  },
  
  // Наушники
  {
    id: 3,
    name: 'Sony WH-1000XM5',
    category: 'headphones',
    level: 'hyper',
    price: 29990,
    oldPrice: 34990,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Премиальные наушники с шумоподавлением'
  },
  {
    id: 8,
    name: 'AirPods Pro 2',
    category: 'headphones',
    level: 'hyper',
    price: 24990,
    oldPrice: 27990,
    rating: 4.6,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Беспроводные наушники с активным шумоподавлением'
  },
  {
    id: 9,
    name: 'JBL Tune 510BT',
    category: 'headphones',
    level: 'level1',
    price: 3990,
    oldPrice: 4990,
    rating: 4.1,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Доступные беспроводные наушники'
  },
  
  // Игровые устройства
  {
    id: 10,
    name: 'PlayStation 5',
    category: 'gaming',
    level: 'level3',
    price: 54990,
    oldPrice: 59990,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Игровая консоль нового поколения'
  },
  {
    id: 11,
    name: 'Xbox Series X',
    category: 'gaming',
    level: 'level3',
    price: 49990,
    oldPrice: 54990,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Мощная игровая консоль от Microsoft'
  },
  {
    id: 12,
    name: 'Nintendo Switch OLED',
    category: 'gaming',
    level: 'level2',
    price: 34990,
    oldPrice: 39990,
    rating: 4.6,
    image: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Портативная игровая консоль с OLED-экраном'
  }
];

let displayedProducts = [];
let currentPage = 1;
const productsPerPage = 9;

// Инициализация каталога
document.addEventListener('DOMContentLoaded', function() {
  loadProducts();
  updateCartCount();
});

// Загрузка товаров
function loadProducts() {
  displayedProducts = [...catalogProducts];
  renderProducts();
}

// Отображение товаров
function renderProducts() {
  const grid = document.getElementById('products-grid');
  const startIndex = 0;
  const endIndex = currentPage * productsPerPage;
  const productsToShow = displayedProducts.slice(startIndex, endIndex);
  
  grid.innerHTML = '';
  
  if (productsToShow.length === 0) {
    grid.innerHTML = '<div class="no-products"><h3>Товары не найдены</h3><p>Попробуйте изменить фильтры поиска</p></div>';
    return;
  }
  
  productsToShow.forEach(product => {
    const productCard = createProductCard(product);
    grid.appendChild(productCard);
  });
  
  // Показать/скрыть кнопку "Загрузить еще"
  const loadMoreBtn = document.querySelector('.load-more-section');
  if (endIndex >= displayedProducts.length) {
    loadMoreBtn.style.display = 'none';
  } else {
    loadMoreBtn.style.display = 'block';
  }
}

// Создание карточки товара
function createProductCard(product) {
  const card = document.createElement('div');
  card.className = 'product-card';
  card.setAttribute('data-3d', 'true');
  card.setAttribute('data-id', product.id);
  
  const levelLabels = {
    'level1': 'LEVEL 1',
    'level2': 'LEVEL 2', 
    'level3': 'LEVEL 3',
    'gaming': 'Gaming',
    'creator': 'Creator',
    'hyper': 'Hyper'
  };
  
  card.innerHTML = `
    <div class="product-badge">${levelLabels[product.level] || product.level}</div>
    <div class="product-image">
      <img src="${product.image}" alt="${product.name}" loading="lazy">
    </div>
    <div class="product-info">
      <h3 class="product-title">${product.name}</h3>
      <p class="product-description">${product.description}</p>
      <div class="product-rating">
        <span class="stars">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</span>
        <span class="rating-number">${product.rating}</span>
      </div>
      <div class="product-price">
        <span class="price-current">${product.price.toLocaleString()} ₽</span>
        ${product.oldPrice ? `<span class="price-old">${product.oldPrice.toLocaleString()} ₽</span>` : ''}
      </div>
      <button class="cart-btn" onclick="addToCart(${product.id})">В КОРЗИНУ</button>
    </div>
  `;
  
  return card;
}

// Фильтрация товаров
function filterProducts() {
  const categoryFilter = document.getElementById('category-filter').value;
  const levelFilter = document.getElementById('level-filter').value;
  const priceFilter = document.getElementById('price-filter').value;
  const searchInput = document.getElementById('search-input').value.toLowerCase();
  
  displayedProducts = catalogProducts.filter(product => {
    // Фильтр по категории
    const matchesCategory = !categoryFilter || product.category === categoryFilter;
    
    // Фильтр по уровню
    const matchesLevel = !levelFilter || product.level === levelFilter;
    
    // Фильтр по цене
    let matchesPrice = true;
    if (priceFilter) {
      const [min, max] = priceFilter.split('-').map(p => p.replace('+', ''));
      const minPrice = parseInt(min) || 0;
      const maxPrice = max ? parseInt(max) : Infinity;
      matchesPrice = product.price >= minPrice && product.price <= maxPrice;
    }
    
    // Фильтр по поиску
    const matchesSearch = !searchInput || 
      product.name.toLowerCase().includes(searchInput) ||
      product.description.toLowerCase().includes(searchInput);
    
    return matchesCategory && matchesLevel && matchesPrice && matchesSearch;
  });
  
  currentPage = 1;
  renderProducts();
}

// Загрузка дополнительных товаров
function loadMoreProducts() {
  currentPage++;
  renderProducts();
}

// Обновление счетчика корзины
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('deviceUP_cart')) || [];
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  const cartCountElement = document.getElementById('cart-count');
  if (cartCountElement) {
    cartCountElement.textContent = count;
  }
}

// Добавление товара в корзину (переопределяем для каталога)
function addToCart(productId) {
  const product = catalogProducts.find(p => p.id === productId);
  if (!product) return;
  
  let cart = JSON.parse(localStorage.getItem('deviceUP_cart')) || [];
  const existingItem = cart.find(item => item.id === productId);
  
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ id: productId, quantity: 1 });
  }
  
  localStorage.setItem('deviceUP_cart', JSON.stringify(cart));
  updateCartCount();
  
  // Визуальная обратная связь
  const button = event.target;
  const originalText = button.textContent;
  button.textContent = '✓ ДОБАВЛЕНО';
  button.classList.add('added');
  
  setTimeout(() => {
    button.textContent = originalText;
    button.classList.remove('added');
  }, 2000);
  
  showNotification(`${product.name} добавлен в корзину!`);
}

// Стили для каталога
const catalogStyles = `
  .catalog-page {
    padding-top: 100px;
    min-height: 100vh;
  }
  
  .page-header {
    text-align: center;
    margin-bottom: 60px;
  }
  
  .back-btn {
    background: rgba(0, 245, 255, 0.1);
    border: 1px solid #00f5ff;
    color: #00f5ff;
    padding: 10px 20px;
    border-radius: 25px;
    cursor: pointer;
    margin-bottom: 20px;
    transition: all 0.3s ease;
  }
  
  .back-btn:hover {
    background: #00f5ff;
    color: #000000;
  }
  
  .page-title {
    font-family: 'Orbitron', monospace;
    font-size: 3rem;
    color: #ffffff;
    margin-bottom: 15px;
    text-shadow: 0 0 20px #00f5ff;
  }
  
  .page-subtitle {
    font-size: 1.2rem;
    color: #cccccc;
  }
  
  .filters-section {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(0, 245, 255, 0.3);
    border-radius: 20px;
    padding: 30px;
    margin-bottom: 40px;
    backdrop-filter: blur(10px);
  }
  
  .filters-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    align-items: end;
  }
  
  .filter-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  
  .filter-group label {
    color: #00f5ff;
    font-weight: 600;
    font-size: 0.9rem;
  }
  
  .filter-group select,
  .filter-group input {
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(0, 245, 255, 0.5);
    color: #ffffff;
    padding: 12px;
    border-radius: 10px;
    font-size: 14px;
  }
  
  .filter-group select:focus,
  .filter-group input:focus {
    outline: none;
    border-color: #00f5ff;
    box-shadow: 0 0 10px rgba(0, 245, 255, 0.3);
  }
  
  .products-section {
    margin-bottom: 60px;
  }
  
  .load-more-section {
    text-align: center;
    margin-top: 40px;
  }
  
  .no-products {
    grid-column: 1 / -1;
    text-align: center;
    padding: 60px 20px;
    color: #cccccc;
  }
  
  .no-products h3 {
    color: #ffffff;
    margin-bottom: 15px;
    font-size: 1.5rem;
  }
  
  @media (max-width: 768px) {
    .page-title {
      font-size: 2rem;
    }
    
    .filters-container {
      grid-template-columns: 1fr;
    }
    
    .products-grid {
      grid-template-columns: 1fr;
    }
  }
`;

// Добавляем стили в документ
const styleSheet = document.createElement('style');
styleSheet.textContent = catalogStyles;
document.head.appendChild(styleSheet);