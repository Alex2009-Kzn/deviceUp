// ДИНАМИЧЕСКИЙ СЧЁТЧИК АГЕНТОВ
let agentCount = 10247;
let reviewsCount = 45892;

// Обновление счетчиков
setInterval(() => {
  agentCount += Math.floor(Math.random() * 10) + 1;
  reviewsCount += Math.floor(Math.random() * 15) + 1;
  
  const agentCounter = document.getElementById('agents-counter');
  const reviewsCounter = document.getElementById('reviews-counter');
  
  if (agentCounter) {
    agentCounter.innerText = agentCount.toLocaleString();
  }
  if (reviewsCounter) {
    reviewsCounter.innerText = reviewsCount.toLocaleString();
  }
}, 17000);

// 3D-ВРАЩЕНИЕ КАРТОЧЕК
document.addEventListener('DOMContentLoaded', function() {
  const cards = document.querySelectorAll('[data-3d="true"]');
  
  cards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      if (window.innerWidth > 768) { // Только на десктопе
        const rect = card.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        
        card.style.transform = `perspective(1000px) rotateY(${x * 15}deg) rotateX(${-y * 15}deg) translateZ(10px)`;
      }
    });
    
    card.addEventListener('mouseleave', () => {
      card.style.transform = 'perspective(1000px) rotateY(0deg) rotateX(0deg) translateZ(0px)';
    });
  });
});

// КОРЗИНА (ЛОКАЛЬНОЕ ХРАНИЛИЩЕ)
class Cart {
  constructor() {
    this.items = JSON.parse(localStorage.getItem('deviceUP_cart')) || [];
    this.products = {
      1: { name: 'Samsung Galaxy A06', price: 89990, image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=200' },
      2: { name: 'ASUS ROG Strix G15', price: 159990, image: 'https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=200' },
      3: { name: 'Sony WH-1000XM5', price: 29990, image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=200' }
    };
    this.updateCartCount();
  }
  
  addProduct(id) {
    const existingItem = this.items.find(item => item.id === id);
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      this.items.push({ id: id, quantity: 1 });
    }
    this.save();
    this.updateCartCount();
    this.showAddedFeedback(id);
  }
  
  removeProduct(id) {
    this.items = this.items.filter(item => item.id !== id);
    this.save();
    this.updateCartCount();
  }
  
  updateQuantity(id, quantity) {
    const item = this.items.find(item => item.id === id);
    if (item) {
      item.quantity = quantity;
      if (quantity <= 0) {
        this.removeProduct(id);
      } else {
        this.save();
      }
    }
    this.updateCartCount();
  }
  
  getTotal() {
    return this.items.reduce((total, item) => {
      const product = this.products[item.id];
      return total + (product ? product.price * item.quantity : 0);
    }, 0);
  }
  
  save() {
    localStorage.setItem('deviceUP_cart', JSON.stringify(this.items));
  }
  
  updateCartCount() {
    const count = this.items.reduce((total, item) => total + item.quantity, 0);
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
      cartCountElement.textContent = count;
    }
  }
  
  showAddedFeedback(id) {
    const button = document.querySelector(`[onclick="addToCart(${id})"]`);
    if (button) {
      const originalText = button.textContent;
      button.textContent = '✓ ДОБАВЛЕНО';
      button.classList.add('added');
      
      setTimeout(() => {
        button.textContent = originalText;
        button.classList.remove('added');
      }, 2000);
    }
  }
}

// ИНИЦИАЛИЗАЦИЯ КОРЗИНЫ
const cart = new Cart();

// Функция добавления в корзину
function addToCart(productId) {
  cart.addProduct(parseInt(productId));
  
  // Анимация добавления
  const button = event.target;
  button.style.transform = 'scale(0.95)';
  setTimeout(() => {
    button.style.transform = 'scale(1)';
  }, 150);
}

// МОДАЛЬНОЕ ОКНО КОРЗИНЫ
function openCart() {
  const modal = document.getElementById('cart-modal');
  const cartItems = document.getElementById('cart-items');
  const cartTotal = document.getElementById('cart-total');
  
  // Очищаем содержимое
  cartItems.innerHTML = '';
  
  if (cart.items.length === 0) {
    cartItems.innerHTML = '<p style="text-align: center; color: #cccccc;">Корзина пуста</p>';
  } else {
    cart.items.forEach(item => {
      const product = cart.products[item.id];
      if (product) {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `
          <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px; padding: 15px; background: rgba(255,255,255,0.05); border-radius: 10px;">
            <img src="${product.image}" alt="${product.name}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;">
            <div style="flex: 1;">
              <h4 style="color: #ffffff; margin-bottom: 5px;">${product.name}</h4>
              <p style="color: #00f5ff; font-weight: bold;">${product.price.toLocaleString()} ₽</p>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <button onclick="cart.updateQuantity(${item.id}, ${item.quantity - 1}); openCart();" style="background: #bd00ff; border: none; color: white; width: 30px; height: 30px; border-radius: 50%; cursor: pointer;">-</button>
              <span style="color: #ffffff; min-width: 20px; text-align: center;">${item.quantity}</span>
              <button onclick="cart.updateQuantity(${item.id}, ${item.quantity + 1}); openCart();" style="background: #00f5ff; border: none; color: white; width: 30px; height: 30px; border-radius: 50%; cursor: pointer;">+</button>
              <button onclick="cart.removeProduct(${item.id}); openCart();" style="background: #ff4444; border: none; color: white; padding: 5px 10px; border-radius: 5px; cursor: pointer; margin-left: 10px;">Удалить</button>
            </div>
          </div>
        `;
        cartItems.appendChild(itemElement);
      }
    });
  }
  
  cartTotal.textContent = cart.getTotal().toLocaleString() + ' ₽';
  modal.style.display = 'block';
}

function closeCart() {
  document.getElementById('cart-modal').style.display = 'none';
}

// МОБИЛЬНОЕ МЕНЮ
function toggleMobileMenu() {
  const nav = document.querySelector('.nav');
  nav.style.display = nav.style.display === 'block' ? 'none' : 'block';
}

// ПЛАВНАЯ ПРОКРУТКА
document.addEventListener('DOMContentLoaded', function() {
  // Плавная прокрутка для якорных ссылок
  const links = document.querySelectorAll('a[href^="#"]');
  links.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
});

// АНИМАЦИЯ ПОЯВЛЕНИЯ ЭЛЕМЕНТОВ
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

// Применяем анимацию к элементам
document.addEventListener('DOMContentLoaded', function() {
  const animatedElements = document.querySelectorAll('.product-card, .benefit-card, .section-title');
  animatedElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
});

// PARTICLES ANIMATION
function createParticles() {
  const container = document.getElementById('particles-container');
  if (!container) return;
  
  for (let i = 0; i < 50; i++) {
    const particle = document.createElement('div');
    particle.style.position = 'absolute';
    particle.style.width = Math.random() * 3 + 1 + 'px';
    particle.style.height = particle.style.width;
    particle.style.background = Math.random() > 0.5 ? '#00f5ff' : '#bd00ff';
    particle.style.borderRadius = '50%';
    particle.style.left = Math.random() * 100 + '%';
    particle.style.top = Math.random() * 100 + '%';
    particle.style.opacity = Math.random() * 0.8 + 0.2;
    particle.style.animation = `float ${Math.random() * 10 + 5}s linear infinite`;
    
    container.appendChild(particle);
  }
}

// Инициализация частиц
document.addEventListener('DOMContentLoaded', createParticles);

// ЗАКРЫТИЕ МОДАЛЬНОГО ОКНА ПО КЛИКУ ВНЕ ЕГО
window.addEventListener('click', function(event) {
  const modal = document.getElementById('cart-modal');
  if (event.target === modal) {
    closeCart();
  }
});

// ФУНКЦИЯ НАЗАД
function goBack() {
  history.back();
}

// ОБРАБОТКА ОШИБОК ЗАГРУЗКИ ИЗОБРАЖЕНИЙ
document.addEventListener('DOMContentLoaded', function() {
  const images = document.querySelectorAll('img');
  images.forEach(img => {
    img.addEventListener('error', function() {
      this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtc2l6ZT0iMTgiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5JbWFnZTwvdGV4dD48L3N2Zz4=';
    });
  });
});

// УВЕДОМЛЕНИЯ
function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 20px;
    background: ${type === 'success' ? '#4CAF50' : '#f44336'};
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    z-index: 3000;
    animation: slideIn 0.3s ease;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// CSS для анимации уведомлений
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;
document.head.appendChild(style);