import React from 'react';
import { Link } from 'react-router-dom';
import { Smartphone, Laptop, Headphones, Gamepad2, Camera, Watch } from 'lucide-react';
import { motion } from 'framer-motion';

const CategoriesSection = () => {
  const categories = [
    {
      icon: Smartphone,
      name: 'Смартфоны',
      levels: ['LEVEL 1', 'LEVEL 2', 'LEVEL 3'],
      description: 'От базовых до флагманских',
      color: 'from-blue-500 to-blue-700',
      image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=500',
    },
    {
      icon: Laptop,
      name: 'Ноутбуки',
      levels: ['For Life', 'Gaming', 'Creator'],
      description: 'Для работы, игр и творчества',
      color: 'from-purple-500 to-purple-700',
      image: 'https://images.pexels.com/photos/205316/pexels-photo-205316.jpeg?auto=compress&cs=tinysrgb&w=500',
    },
    {
      icon: Headphones,
      name: 'Наушники',
      levels: ['Classic', 'Hyper', 'Energy'],
      description: 'Качественный звук для всех',
      color: 'from-green-500 to-green-700',
      image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=500',
    },
    {
      icon: Gamepad2,
      name: 'Игровые устройства',
      levels: ['Entry', 'Pro', 'Elite'],
      description: 'Консоли и аксессуары',
      color: 'from-red-500 to-red-700',
      image: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=500',
    },
    {
      icon: Camera,
      name: 'Камеры',
      levels: ['Basic', 'Advanced', 'Pro'],
      description: 'Фото и видеооборудование',
      color: 'from-yellow-500 to-orange-600',
      image: 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=500',
    },
    {
      icon: Watch,
      name: 'Умные часы',
      levels: ['Sport', 'Smart', 'Premium'],
      description: 'Технологии на запястье',
      color: 'from-indigo-500 to-indigo-700',
      image: 'https://images.pexels.com/photos/393047/pexels-photo-393047.jpeg?auto=compress&cs=tinysrgb&w=500',
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Категории <span className="text-blue-600">техники</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Каждая категория разделена на уровни для точного подбора под ваши потребности и бюджет
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
            >
              <Link
                to="/catalog"
                className="group block relative overflow-hidden bg-white rounded-2xl shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
              >
                {/* Background Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent`} />
                  
                  {/* Icon */}
                  <div className="absolute top-4 left-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${category.color} p-3 shadow-lg`}>
                      <category.icon className="h-6 w-6 text-white" />
                    </div>
                  </div>

                  {/* Levels */}
                  <div className="absolute top-4 right-4 flex flex-col space-y-1">
                    {category.levels.map((level, levelIndex) => (
                      <span
                        key={levelIndex}
                        className="bg-white/90 backdrop-blur-sm text-xs font-medium px-2 py-1 rounded-full text-gray-800"
                      >
                        {level}
                      </span>
                    ))}
                  </div>

                  {/* Category Name */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-bold text-white mb-1">
                      {category.name}
                    </h3>
                    <p className="text-white/90 text-sm">
                      {category.description}
                    </p>
                  </div>
                </div>

                {/* Bottom Content */}
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500 font-medium">
                      Перейти в каталог
                    </span>
                    <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center group-hover:bg-blue-600 transition-colors duration-300">
                      <svg className="w-3 h-3 text-blue-600 group-hover:text-white transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Bottom Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center space-x-8 bg-gray-50 rounded-2xl px-8 py-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">1000+</div>
              <div className="text-sm text-gray-600">Товаров</div>
            </div>
            <div className="h-8 w-px bg-gray-300" />
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">50+</div>
              <div className="text-sm text-gray-600">Брендов</div>
            </div>
            <div className="h-8 w-px bg-gray-300" />
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">24/7</div>
              <div className="text-sm text-gray-600">Поддержка</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CategoriesSection;