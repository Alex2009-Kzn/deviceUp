import React from 'react';
import { Shield, Users, Target, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';

const BenefitsSection = () => {
  const benefits = [
    {
      icon: Shield,
      title: 'Блокчейн-верификация',
      description: 'Каждый отзыв проверяется через блокчейн, исключая подделки и обеспечивая полную прозрачность оценок.',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Users,
      title: 'UP Army',
      description: 'Сообщество реальных пользователей, которые делятся честным опытом использования техники.',
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Target,
      title: 'Персональный подбор',
      description: 'ИИ-алгоритм анализирует ваши потребности и подбирает идеальную технику именно для вас.',
      color: 'from-orange-500 to-red-500',
    },
    {
      icon: MessageSquare,
      title: 'Экспертное сообщество',
      description: 'Получайте советы от опытных пользователей и технических экспертов в режиме реального времени.',
      color: 'from-green-500 to-emerald-500',
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Почему выбирают <span className="text-blue-600">deviceUP</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Мы революционизируем процесс выбора техники, делая его прозрачным, персональным и основанным на реальном опыте пользователей
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group relative"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-500 group-hover:-translate-y-2">
                {/* Icon */}
                <div className="relative mb-6">
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-r ${benefit.color} p-4 shadow-lg`}>
                    <benefit.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className={`absolute inset-0 w-16 h-16 rounded-xl bg-gradient-to-r ${benefit.color} blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300`} />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">
                  {benefit.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>

                {/* Hover effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-center mt-16"
        >
          <div className="inline-flex items-center space-x-2 bg-blue-50 border border-blue-100 rounded-full px-6 py-3 text-blue-700 text-sm font-medium">
            <Shield className="h-4 w-4" />
            <span>Более 98% точности подбора техники</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default BenefitsSection;