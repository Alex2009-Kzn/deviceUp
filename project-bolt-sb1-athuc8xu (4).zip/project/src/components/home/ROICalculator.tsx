import React, { useState } from 'react';
import { Calculator, TrendingUp, DollarSign, Target } from 'lucide-react';
import { motion } from 'framer-motion';

const ROICalculator = () => {
  const [formData, setFormData] = useState({
    devicePrice: 50000,
    usagePeriod: 24,
    productivityGain: 15,
    monthlyIncome: 80000,
  });

  const [results, setResults] = useState(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: parseInt(value) || 0
    }));
  };

  const calculateROI = () => {
    setIsCalculating(true);
    
    setTimeout(() => {
      const monthlyProductivityIncrease = (formData.monthlyIncome * formData.productivityGain) / 100;
      const totalAdditionalIncome = monthlyProductivityIncrease * formData.usagePeriod;
      const netProfit = totalAdditionalIncome - formData.devicePrice;
      const roiPercentage = ((netProfit / formData.devicePrice) * 100);

      setResults({
        monthlyIncrease: monthlyProductivityIncrease,
        totalIncome: totalAdditionalIncome,
        netProfit: netProfit,
        roiPercentage: roiPercentage,
        paybackPeriod: Math.ceil(formData.devicePrice / monthlyProductivityIncrease)
      });
      setIsCalculating(false);
    }, 1500);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 bg-blue-100 border border-blue-200 rounded-full px-4 py-2 text-blue-700 text-sm font-medium mb-6">
            <Calculator className="h-4 w-4" />
            <span>ROI Калькулятор</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Рассчитайте окупаемость <span className="text-blue-400">вашей техники</span>
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Узнайте, как новая техника повысит вашу продуктивность и принесет дополнительный доход
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Calculator Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/10"
          >
            <h3 className="text-2xl font-bold text-white mb-8">Введите параметры</h3>
            
            <div className="space-y-6">
              {/* Device Price */}
              <div>
                <label className="block text-white font-medium mb-3">
                  Стоимость устройства (₽)
                </label>
                <div className="relative">
                  <input
                    type="range"
                    min="10000"
                    max="200000"
                    step="5000"
                    value={formData.devicePrice}
                    onChange={(e) => handleInputChange('devicePrice', e.target.value)}
                    className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-sm text-gray-300 mt-2">
                    <span>10K</span>
                    <span className="font-semibold text-blue-400">{formatCurrency(formData.devicePrice)}</span>
                    <span>200K</span>
                  </div>
                </div>
              </div>

              {/* Usage Period */}
              <div>
                <label className="block text-white font-medium mb-3">
                  Период использования (месяцев)
                </label>
                <div className="relative">
                  <input
                    type="range"
                    min="6"
                    max="60"
                    step="6"
                    value={formData.usagePeriod}
                    onChange={(e) => handleInputChange('usagePeriod', e.target.value)}
                    className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-sm text-gray-300 mt-2">
                    <span>6 мес</span>
                    <span className="font-semibold text-blue-400">{formData.usagePeriod} мес</span>
                    <span>5 лет</span>
                  </div>
                </div>
              </div>

              {/* Productivity Gain */}
              <div>
                <label className="block text-white font-medium mb-3">
                  Прирост продуктивности (%)
                </label>
                <div className="relative">
                  <input
                    type="range"
                    min="5"
                    max="50"
                    step="5"
                    value={formData.productivityGain}
                    onChange={(e) => handleInputChange('productivityGain', e.target.value)}
                    className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-sm text-gray-300 mt-2">
                    <span>5%</span>
                    <span className="font-semibold text-blue-400">{formData.productivityGain}%</span>
                    <span>50%</span>
                  </div>
                </div>
              </div>

              {/* Monthly Income */}
              <div>
                <label className="block text-white font-medium mb-3">
                  Месячный доход (₽)
                </label>
                <div className="relative">
                  <input
                    type="range"
                    min="30000"
                    max="300000"
                    step="10000"
                    value={formData.monthlyIncome}
                    onChange={(e) => handleInputChange('monthlyIncome', e.target.value)}
                    className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-sm text-gray-300 mt-2">
                    <span>30K</span>
                    <span className="font-semibold text-blue-400">{formatCurrency(formData.monthlyIncome)}</span>
                    <span>300K</span>
                  </div>
                </div>
              </div>

              <button
                onClick={calculateROI}
                disabled={isCalculating}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCalculating ? 'Рассчитываем...' : 'Рассчитать ROI'}
              </button>
            </div>
          </motion.div>

          {/* Results */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-6"
          >
            {isCalculating && (
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <div className="text-center">
                  <div className="animate-spin w-12 h-12 border-4 border-blue-400 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-white">Анализируем данные...</p>
                </div>
              </div>
            )}

            {results && !isCalculating && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="space-y-4"
              >
                {/* ROI Percentage */}
                <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-sm rounded-2xl p-6 border border-green-500/30">
                  <div className="flex items-center space-x-3 mb-3">
                    <TrendingUp className="h-6 w-6 text-green-400" />
                    <h4 className="text-lg font-semibold text-white">ROI</h4>
                  </div>
                  <div className="text-3xl font-bold text-green-400">
                    {results.roiPercentage > 0 ? '+' : ''}{results.roiPercentage.toFixed(1)}%
                  </div>
                  <p className="text-gray-300 text-sm mt-1">Возврат инвестиций</p>
                </div>

                {/* Monthly Increase */}
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
                  <div className="flex items-center space-x-3 mb-3">
                    <DollarSign className="h-6 w-6 text-blue-400" />
                    <h4 className="text-lg font-semibold text-white">Месячный прирост</h4>
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {formatCurrency(results.monthlyIncrease)}
                  </div>
                  <p className="text-gray-300 text-sm mt-1">Дополнительный доход в месяц</p>
                </div>

                {/* Total Income */}
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
                  <div className="flex items-center space-x-3 mb-3">
                    <Target className="h-6 w-6 text-purple-400" />
                    <h4 className="text-lg font-semibold text-white">Общий доход</h4>
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {formatCurrency(results.totalIncome)}
                  </div>
                  <p className="text-gray-300 text-sm mt-1">За весь период использования</p>
                </div>

                {/* Payback Period */}
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
                  <div className="flex items-center space-x-3 mb-3">
                    <Calculator className="h-6 w-6 text-yellow-400" />
                    <h4 className="text-lg font-semibold text-white">Окупаемость</h4>
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {results.paybackPeriod} {results.paybackPeriod === 1 ? 'месяц' : results.paybackPeriod < 5 ? 'месяца' : 'месяцев'}
                  </div>
                  <p className="text-gray-300 text-sm mt-1">Срок окупаемости устройства</p>
                </div>
              </motion.div>
            )}

            {!results && !isCalculating && (
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/10 text-center">
                <Calculator className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-xl font-semibold text-white mb-2">Готов к расчетам</h4>
                <p className="text-gray-300">
                  Настройте параметры слева и нажмите "Рассчитать ROI" для получения результатов
                </p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ROICalculator;