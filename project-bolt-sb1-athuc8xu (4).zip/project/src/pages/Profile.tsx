import React from 'react';
import { User, Package, Star, Settings } from 'lucide-react';

const Profile = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Личный кабинет</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <User className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Пользователь</h3>
                <p className="text-gray-600">UP Army Member</p>
              </div>

              <nav className="space-y-2">
                <a href="#" className="flex items-center space-x-3 px-4 py-3 bg-blue-50 text-blue-600 rounded-lg">
                  <User className="h-5 w-5" />
                  <span>Профиль</span>
                </a>
                <a href="#" className="flex items-center space-x-3 px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <Package className="h-5 w-5" />
                  <span>Заказы</span>
                </a>
                <a href="#" className="flex items-center space-x-3 px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <Star className="h-5 w-5" />
                  <span>Отзывы</span>
                </a>
                <a href="#" className="flex items-center space-x-3 px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg">
                  <Settings className="h-5 w-5" />
                  <span>Настройки</span>
                </a>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Профиль в разработке</h2>
              <p className="text-gray-600">Скоро здесь будет полноценный личный кабинет с управлением заказами, отзывами и настройками.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;