import React from 'react';
import { Users, Target, Award, Zap } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            О <span className="text-blue-600">deviceUP</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Мы создали революционную платформу для выбора техники, которая объединяет блокчейн-технологии, 
            искусственный интеллект и сообщество экспертов.
          </p>
        </div>

        {/* Mission */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 text-blue-700 text-sm font-medium mb-6">
              <Target className="h-4 w-4" />
              <span>Наша миссия</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Сделать выбор техники осознанным и приятным
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              deviceUP родился из желания изменить опыт покупки электроники. Мы устали от поддельных отзывов, 
              неточных рекомендаций и сложности выбора среди тысяч товаров.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Наша платформа использует блокчейн для верификации отзывов, ИИ для персонального подбора 
              и сообщество UP Army для получения экспертных мнений.
            </p>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Team working"
              className="rounded-2xl shadow-2xl"
            />
          </div>
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          <div className="text-center p-8 rounded-2xl bg-gray-50">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl mx-auto mb-6 flex items-center justify-center">
              <Users className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Сообщество</h3>
            <p className="text-gray-600">
              Мы строим сообщество людей, которые ценят качество и делятся честным опытом использования техники.
            </p>
          </div>

          <div className="text-center p-8 rounded-2xl bg-gray-50">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl mx-auto mb-6 flex items-center justify-center">
              <Zap className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Инновации</h3>
            <p className="text-gray-600">
              Используем передовые технологии: блокчейн, ИИ и машинное обучение для решения реальных проблем.
            </p>
          </div>

          <div className="text-center p-8 rounded-2xl bg-gray-50">
            <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl mx-auto mb-6 flex items-center justify-center">
              <Award className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Качество</h3>
            <p className="text-gray-600">
              Каждый отзыв проверяется, каждая рекомендация основана на данных, каждое решение - на экспертизе.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-8">deviceUP в цифрах</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <div className="text-4xl font-bold mb-2">50K+</div>
              <div className="text-white/80">Пользователей</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">12K+</div>
              <div className="text-white/80">Верифицированных отзывов</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">1000+</div>
              <div className="text-white/80">Товаров в каталоге</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">98%</div>
              <div className="text-white/80">Точность подбора</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;