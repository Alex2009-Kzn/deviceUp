import React from 'react';
import { Target } from 'lucide-react';

const Quiz = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 text-blue-700 text-sm font-medium mb-4">
            <Target className="h-4 w-4" />
            <span>Персональный подбор</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Квиз подбора техники</h1>
          <p className="text-lg text-gray-600">Ответьте на несколько вопросов, и мы подберем идеальную технику для ваших потребностей</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Квиз в разработке</h2>
          <p className="text-gray-600">Скоро здесь появится интерактивный квиз для подбора техники на основе ваших потребностей.</p>
        </div>
      </div>
    </div>
  );
};

export default Quiz;