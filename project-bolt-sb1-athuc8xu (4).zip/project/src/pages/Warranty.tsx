import React from 'react';
import { Shield, Clock, RefreshCw, Phone } from 'lucide-react';

const Warranty = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-green-100 rounded-full px-4 py-2 text-green-700 text-sm font-medium mb-6">
            <Shield className="h-4 w-4" />
            <span>Гарантийная программа</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Гарантия deviceUP</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Мы обеспечиваем полную защиту ваших покупок с расширенной гарантийной программой
          </p>
        </div>

        {/* Warranty Types */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="flex items-center space-x-3 mb-6">
              <Clock className="h-8 w-8 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">Стандартная гарантия</h2>
            </div>
            <ul className="space-y-4 text-gray-600">
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                <span>12 месяцев официальной гарантии производителя</span>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                <span>Бесплатный ремонт или замена при производственных дефектах</span>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                <span>Техническая поддержка 24/7</span>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                <span>Возврат в течение 14 дней без объяснения причин</span>
              </li>
            </ul>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-lg p-8 text-white">
            <div className="flex items-center space-x-3 mb-6">
              <Shield className="h-8 w-8 text-white" />
              <h2 className="text-2xl font-bold">UP-Premium гарантия</h2>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                <span>24 месяца расширенной гарантии</span>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                <span>Покрытие случайных повреждений</span>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                <span>Экспресс-замена в течение 24 часов</span>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                <span>Персональный менеджер поддержки</span>
              </li>
            </ul>
            <div className="mt-6 p-4 bg-white/20 rounded-lg">
              <p className="text-sm font-medium">Доступно для участников UP Army</p>
            </div>
          </div>
        </div>

        {/* Process */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Процесс гарантийного обслуживания</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Phone className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">1. Обращение</h3>
              <p className="text-gray-600">Свяжитесь с нами любым удобным способом для описания проблемы</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">2. Диагностика</h3>
              <p className="text-gray-600">Наши специалисты проведут диагностику и определят способ решения</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <RefreshCw className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">3. Решение</h3>
              <p className="text-gray-600">Ремонт, замена или возврат средств в соответствии с гарантией</p>
            </div>
          </div>
        </div>

        {/* Contact Info */}
        <div className="bg-gray-100 rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Гарантийная служба</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Телефон</h3>
              <p className="text-blue-600 font-medium">+7 (800) 123-45-67</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Email</h3>
              <p className="text-blue-600 font-medium">warranty@deviceup.ru</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Время работы</h3>
              <p className="text-gray-600">Круглосуточно, 7 дней в неделю</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Warranty;