import React from 'react';
import HeroSection from '../components/home/HeroSection';
import BenefitsSection from '../components/home/BenefitsSection';
import CategoriesSection from '../components/home/CategoriesSection';
import ArmySection from '../components/home/ArmySection';
import ROICalculator from '../components/home/ROICalculator';
import CTASection from '../components/home/CTASection';

const Home = () => {
  return (
    <div className="overflow-hidden">
      <HeroSection />
      <BenefitsSection />
      <CategoriesSection />
      <ArmySection />
      <ROICalculator />
      <CTASection />
    </div>
  );
};

export default Home;