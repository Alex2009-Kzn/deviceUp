import React from 'react';
import { Users, Star, Trophy, Gift, ArrowRight, Shield } from 'lucide-react';

const Army = () => {
  const steps = [
    {
      number: '01',
      title: 'Покупка техники',
      description: 'Приобретите любой товар в deviceUP на сумму от 15,000 ₽',
      icon: '🛒',
    },
    {
      number: '02',
      title: 'Отзыв через 14 дней',
      description: 'Оставьте подробный отзыв после 2 недель использования',
      icon: '⭐',
    },
    {
      number: '03',
      title: 'Блокчейн-верификация',
      description: 'Ваш отзыв проходит верификацию в блокчейн-сети',
      icon: '🔐',
    },
    {
      number: '04',
      title: 'Получение статуса',
      description: 'Добро пожаловать в UP Army с эксклюзивными привилегиями',
      icon: '🎖️',
    },
  ];

  const benefits = [
    {
      icon: Gift,
      title: 'Ранний доступ',
      description: 'Первыми узнавайте о новинках и предзаказах',
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: Trophy,
      title: 'Специальные скидки',
      description: 'Скидки до 25% на все товары в каталоге',
      color: 'from-green-500 to-green-600',
    },
    {
      icon: Users,
      title: 'Экспертные встречи',
      description: 'Участие в закрытых вебинарах и встречах',
      color: 'from-purple-500 to-purple-600',
    },
    {
      icon: Shield,
      title: 'UP-Premium гарантия',
      description: 'Расширенная гарантия до 24 месяцев',
      color: 'from-orange-500 to-orange-600',
    },
  ];

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full px-6 py-3 text-blue-700 text-sm font-medium mb-6">
            <Users className="h-4 w-4" />
            <span>Эксклюзивная программа</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Добро пожаловать в <span className="text-blue-600">UP Army</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Эксклюзивное сообщество экспертов и энтузиастов техники. Получайте привилегии, 
            делитесь опытом и влияйте на будущее индустрии электроники.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">12,500+</div>
            <div className="text-gray-600">Участников</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">45,000+</div>
            <div className="text-gray-600">Отзывов</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">98.5%</div>
            <div className="text-gray-600">Точность</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">100%</div>
            <div className="text-gray-600">Блокчейн-защита</div>
          </div>
        </div>

        {/* How to Join */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Как присоединиться к UP Army
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 transition-colors duration-300">
                  <div className="text-4xl mb-4 text-center">{step.icon}</div>
                  <div className="text-sm font-bold text-blue-600 mb-2">ШАГ {step.number}</div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="h-6 w-6 text-gray-300" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Benefits */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Привилегии участников UP Army
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="group relative overflow-hidden bg-white rounded-2xl shadow-lg border border-gray-100 p-8 hover:shadow-2xl transition-all duration-300">
                <div className={`w-16 h-16 bg-gradient-to-r ${benefit.color} rounded-xl mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <benefit.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{benefit.title}</h3>
                <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
                <div className={`absolute inset-0 bg-gradient-to-r ${benefit.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-6">Готовы присоединиться?</h2>
          <p className="text-xl mb-8 opacity-90">
            Начните с покупки любого товара и станьте частью эксклюзивного сообщества
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
              Перейти в каталог
            </button>
            <button className="bg-white/20 backdrop-blur-sm text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors duration-300">
              Узнать больше
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Army;